# Astra UI

Astra UI is Daeron's private Android command center for local coding agents. Built with Expo SDK 57, React Native 0.86, Expo Router, and TypeScript, it provides a mobile-first control surface where each rig runs its own local backend and the phone streams telemetry, inspects diffs, resolves execution approvals, and edits per-agent configuration. Nothing is published to an app store or routed through a cloud backend.

First-class active providers in this build are **Factory Droid** and **Codex**. **OpenCode**, **Google AntiGravity**, and **DeepSeek Harness** are registered in the provider catalog as planned targets for subsequent integration passes.

## Quickstart

Install Node.js LTS on the host machine and Expo Go (SDK 57 compatible) on your Android device. Run in the repository root:

```sh
npm ci
npx expo start
```

Keep the workstation and Android phone on the same Wi-Fi network, then scan the Metro QR code in Expo Go. If the installed Expo Go build does not match SDK 57, install the matching version from <https://expo.dev/go> or build the standalone preview APK below.

For a local desktop browser preview:

```sh
npm run web
```

Fonts (`Inter`, `JetBrains Mono`, `Space Grotesk`) are bundled as local assets and loaded by `src/app/_layout.tsx`. No agent daemon is required to run the demo scaffold.

## Commands

| Command | Purpose |
| --- | --- |
| `npm ci` | Install locked dependencies |
| `npx expo start` | Start the Metro development server |
| `npm run web` | Start the web preview in a desktop browser |
| `npm run typecheck` | Run `tsc --noEmit` static type verification |
| `npx expo lint` | Run Expo lint checks |
| `npx expo install --fix` | Align package versions with Expo SDK 57 |
| `npx expo-doctor` | Diagnose Expo config and dependency health |
| `npm run export` | Export the static web bundle (`expo export --platform web`) |

## Architecture & File Responsibility

Navigation is managed by **Expo Router** under `src/app/`. Non-route modules live under `src/theme/`, `src/components/`, `src/providers/`, `src/transport/`, and `src/state/`.

| Path | Responsibility |
| --- | --- |
| `src/app/_layout.tsx` | Root Expo Router layout; loads bundled fonts and mounts state/theme providers |
| `src/app/index.tsx` | Command deck: rig selector strip, telemetry summary, active and planned provider cards |
| `src/app/agent/[provider]/index.tsx` | Provider workspace: sessions list, quick actions, model/mode overview, rig context |
| `src/app/agent/[provider]/session/[sid].tsx` | Live session stream view and bottom command/prompt composer |
| `src/app/agent/[provider]/settings.tsx` | Schema-generated per-agent configuration editor |
| `src/app/agent/[provider]/changes.tsx` | Working-tree diff inspection per provider |
| `src/app/approvals.tsx` | Cross-agent execution approval inbox |
| `src/app/machines/[id].tsx` | Machine detail view, rig telemetry, and LAN endpoint address editor |
| `src/theme/tokens.ts` | Frozen Somnus visual contract: obsidian palette, glass hierarchy, typography scale, spacing, radii, motion |
| `src/components/ui/` | Core primitives: `Shell`, `GlassPanel`, `Button`, `Chip`, `StatusDot`, `SectionHeader`, `Sheet`, `ListRow`, `Metric`, `CodeBlock`, `Icon` |
| `src/components/agent/` | Domain components: `ProviderCard`, `StreamView`, `Composer`, `ApprovalCard`, `DiffCard` |
| `src/providers/registry.ts` | Provider registry and configuration schemas (Droid and Codex active; OpenCode, AntiGravity, DeepSeek Harness planned) |
| `src/transport/types.ts` | `AgentTransport` interface contract for sessions, streams, approvals, diffs, and machine metrics |
| `src/transport/demo.ts` | `DemoTransport` deterministic local fixtures implementing `AgentTransport` |
| `src/state/agent-store.tsx` | React context + `AsyncStorage` persistence (`astra.rig-addresses.v2` and `astra.agent-settings.v1`) |
| `docs/FACTORY.md` | Visual contract, architecture specification, demo boundaries, and LAN integration rules |
| `docs/VALIDATION.md` | Verification gate checklist and current execution status |

## Demo Boundaries

- **Persisted state:** Only machine LAN addresses (`astra.rig-addresses.v2`) and per-agent configuration settings (`astra.agent-settings.v1`) persist across restarts via `AsyncStorage`.
- **Fixture state:** Sessions, token streams, working-tree diffs, pending approvals, and rig hardware metrics are served in-memory by `DemoTransport` (`src/transport/demo.ts`). Interactive actions (sending prompts, resolving approvals, toggling settings, editing machine endpoints) mutate state within the running session, and persisted keys survive reload.
- **Zero external network calls:** No socket or HTTP connection is opened to a rig in this scaffold. There is no cloud relay, no automatic LAN discovery service, and no synchronized external database.

## Standalone Android APK (EAS Preview)

`eas.json` defines an internal `preview` profile configured to output a directly installable Android `.apk` (`"buildType": "apk"`). To build with an Expo account:

```sh
npx eas-cli@latest login
npx eas-cli@latest build:configure
npx eas-cli@latest build --platform android --profile preview
```

Download the artifact from the EAS build URL and install it directly on the target Android device (e.g., Galaxy S24 Ultra). Reference: <https://docs.expo.dev/build-reference/apk/>.
