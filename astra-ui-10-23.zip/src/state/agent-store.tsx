import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { activeProviderIds, seedMachines } from '../providers/registry';
import { DemoTransport } from '../transport/demo';
import type {
  AgentSettings,
  AgentTransport,
  Autonomy,
  ExecutionMode,
  Machine,
  ProviderId,
  SessionSummary,
} from '../transport/types';

const ADDRESS_KEY = 'astra.rig-addresses.v2';
const SETTINGS_KEY = 'astra.agent-settings.v1';

/** http/https only, no credentials (no '@'), no whitespace. */
const ADDRESS_PATTERN = /^https?:\/\/[^\s@]+$/i;

const MODES: readonly ExecutionMode[] = ['build', 'plan'];
const AUTONOMY_LEVELS: readonly Autonomy[] = ['readonly', 'assisted', 'full'];
const EFFORT_LEVELS: readonly AgentSettings['effort'][] = ['low', 'medium', 'high'];

function isValidAddress(url: string): boolean {
  return ADDRESS_PATTERN.test(url.trim());
}

function defaultSettings(): Record<ProviderId, AgentSettings> {
  const build = (id: ProviderId, override: Partial<AgentSettings> = {}): AgentSettings => ({
    model: '',
    mode: 'plan',
    autonomy: 'readonly',
    effort: 'medium',
    extra: {},
    ...override,
  });

  return {
    droid: build('droid', { model: 'glm-5.3-flash', mode: 'build', autonomy: 'assisted' }),
    codex: build('codex', { model: 'gpt-5-codex', mode: 'build', autonomy: 'assisted' }),
    opencode: build('opencode', { effort: 'low' }),
    antigravity: build('antigravity', { effort: 'low' }),
    deepseek: build('deepseek', { effort: 'low' }),
  };
}

function mergeAddresses(stored: unknown, base: Machine[]): Machine[] | null {
  if (typeof stored !== 'object' || stored === null) return null;
  const rec = stored as Record<string, unknown>;
  let touched = false;
  const next = base.map((m) => {
    const addr = rec[m.id];
    if (typeof addr === 'string' && isValidAddress(addr) && addr.trim() !== m.address) {
      touched = true;
      return { ...m, address: addr.trim() };
    }
    return m;
  });
  return touched ? next : null;
}

function mergeSettings(
  stored: unknown,
  base: Record<ProviderId, AgentSettings>,
): Record<ProviderId, AgentSettings> | null {
  if (typeof stored !== 'object' || stored === null) return null;
  const rec = stored as Record<string, unknown>;
  const next: Record<ProviderId, AgentSettings> = { ...base };
  let touched = false;

  for (const id of Object.keys(base) as ProviderId[]) {
    const patch = rec[id];
    if (typeof patch !== 'object' || patch === null) continue;
    const p = patch as Record<string, unknown>;
    const cur = base[id];
    const merged: AgentSettings = {
      model: typeof p.model === 'string' ? p.model : cur.model,
      mode: MODES.includes(p.mode as ExecutionMode) ? (p.mode as ExecutionMode) : cur.mode,
      autonomy: AUTONOMY_LEVELS.includes(p.autonomy as Autonomy)
        ? (p.autonomy as Autonomy)
        : cur.autonomy,
      effort: EFFORT_LEVELS.includes(p.effort as AgentSettings['effort'])
        ? (p.effort as AgentSettings['effort'])
        : cur.effort,
      extra: cur.extra,
    };
    if (
      merged.model !== cur.model ||
      merged.mode !== cur.mode ||
      merged.autonomy !== cur.autonomy ||
      merged.effort !== cur.effort
    ) {
      touched = true;
      next[id] = merged;
    }
  }
  return touched ? next : null;
}

interface AstraContextValue {
  machines: Machine[];
  updateAddress: (machineId: string, url: string) => void;
  settings: Record<ProviderId, AgentSettings>;
  updateSettings: (providerId: ProviderId, patch: Partial<AgentSettings>) => void;
  transport: AgentTransport;
  sessions: SessionSummary[];
  warning: string | null;
}

const AstraContext = createContext<AstraContextValue | null>(null);

export function AgentProvider({ children }: { children: React.ReactNode }) {
  const [machines, setMachines] = useState<Machine[]>(seedMachines);
  const [settings, setSettings] = useState<Record<ProviderId, AgentSettings>>(defaultSettings);
  const [sessions, setSessions] = useState<SessionSummary[]>([]);
  const [warning, setWarning] = useState<string | null>(null);

  const transport: AgentTransport = DemoTransport;

  useEffect(() => {
    let cancelled = false;
    void Promise.all(
      activeProviderIds.map((provider) =>
        DemoTransport.listSessions(seedMachines[0], provider),
      ),
    )
      .then((groups) => {
        if (!cancelled) setSessions(groups.flat());
      })
      .catch(() => {
        if (!cancelled) setWarning('Demo fixtures failed to load.');
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const [rawAddresses, rawSettings] = await Promise.all([
          AsyncStorage.getItem(ADDRESS_KEY),
          AsyncStorage.getItem(SETTINGS_KEY),
        ]);
        if (cancelled) return;
        if (rawAddresses !== null) {
          const next = mergeAddresses(JSON.parse(rawAddresses), seedMachines);
          if (next) setMachines(next);
        }
        if (rawSettings !== null) {
          const next = mergeSettings(JSON.parse(rawSettings), defaultSettings());
          if (next) setSettings(next);
        }
      } catch {
        if (!cancelled) {
          setWarning('Stored rig addresses or agent settings could not be read — using seeds.');
        }
      }
    };
    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  const updateAddress = useCallback(
    (machineId: string, url: string) => {
      const trimmed = url.trim();
      if (!isValidAddress(trimmed)) {
        setWarning('Address must be a plain http(s) URL without credentials.');
        return;
      }
      const next = machines.map((m) => (m.id === machineId ? { ...m, address: trimmed } : m));
      setMachines(next);
      const addressMap = Object.fromEntries(next.map((m) => [m.id, m.address]));
      void AsyncStorage.setItem(ADDRESS_KEY, JSON.stringify(addressMap)).catch(() => {
        setWarning('Rig address could not be persisted — it will reset on restart.');
      });
    },
    [machines],
  );

  const updateSettings = useCallback(
    (providerId: ProviderId, patch: Partial<AgentSettings>) => {
      const next: Record<ProviderId, AgentSettings> = {
        ...settings,
        [providerId]: { ...settings[providerId], ...patch },
      };
      setSettings(next);
      void AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(next)).catch(() => {
        setWarning('Agent settings could not be persisted — they will reset on restart.');
      });
    },
    [settings],
  );

  const value = useMemo<AstraContextValue>(
    () => ({ machines, updateAddress, settings, updateSettings, transport, sessions, warning }),
    [machines, updateAddress, settings, updateSettings, transport, sessions, warning],
  );

  return <AstraContext.Provider value={value}>{children}</AstraContext.Provider>;
}

export function useAstra(): AstraContextValue {
  const ctx = useContext(AstraContext);
  if (!ctx) {
    throw new Error('useAstra must be used inside <AgentProvider>.');
  }
  return ctx;
}
