import { useState } from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { SessionRow } from '../../components/agent/SessionRow';
import { UnknownRoute } from '../../components/agent/Notices';
import { countByStatus, newestFirst } from '../../components/agent/format';
import { useMachineParam } from '../../components/agent/useRouteParams';
import { Button } from '../../components/ui/Button';
import { Chip } from '../../components/ui/Chip';
import { GlassPanel } from '../../components/ui/GlassPanel';
import { Metric } from '../../components/ui/Metric';
import { SectionHeader } from '../../components/ui/SectionHeader';
import { Shell } from '../../components/ui/Shell';
import { useAstra } from '../../state/agent-store';
import { colors, fonts, layout, radius, space, type as typeScale } from '../../theme/tokens';

type Feedback = { kind: 'success' | 'error'; message: string } | null;

function validateAddress(raw: string): string | null {
  const value = raw.trim();
  if (value.length === 0) return 'ADDRESS REQUIRED';
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    return 'NOT A VALID URL · EXPECTED http://host:port';
  }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return 'PROTOCOL MUST BE http OR https';
  if (parsed.hostname.length === 0) return 'HOST REQUIRED';
  if (parsed.username.length > 0 || parsed.password.length > 0 || value.includes('@')) {
    return 'CREDENTIALS NOT ALLOWED IN ADDRESS';
  }
  return null;
}

export default function MachineScreen() {
  const id = useMachineParam();
  const { machines, sessions, updateAddress } = useAstra();
  const machine = machines.find((candidate) => candidate.id === id);
  const [draft, setDraft] = useState(machine?.address ?? '');
  const [feedback, setFeedback] = useState<Feedback>(null);
  const [syncedAddress, setSyncedAddress] = useState(machine?.address);

  const savedAddress = machine?.address;
  if (savedAddress !== undefined && syncedAddress !== savedAddress) {
    setSyncedAddress(savedAddress);
    setDraft(savedAddress);
  }

  if (!machine) {
    return <UnknownRoute title="Unknown machine" detail="The requested machine is not in the machine list." />;
  }

  const onMachine = newestFirst(sessions.filter((session) => session.deviceId === machine.id));
  const dirty = draft.trim() !== machine.address;

  const save = () => {
    const problem = validateAddress(draft);
    if (problem) {
      setFeedback({ kind: 'error', message: problem });
      return;
    }
    updateAddress(machine.id, draft.trim());
    setFeedback({ kind: 'success', message: 'ADDRESS SAVED ON THIS DEVICE' });
  };

  return (
    <Shell title={machine.name} eyebrow={machine.os} back>
      <Chip label="Not probed · demo transport" tone="neutral" dot />

      <SectionHeader title="Telemetry" />
      <GlassPanel style={styles.metrics}>
        <Metric label="Sessions" value={onMachine.length} large />
        <Metric label="Running" value={countByStatus(onMachine, 'running')} large color={colors.live} />
        <Metric label="Awaiting" value={countByStatus(onMachine, 'awaiting-approval')} large color={colors.warning} />
      </GlassPanel>

      <SectionHeader title="Bridge address" />
      <View style={styles.form}>
        <TextInput
          accessibilityLabel="Bridge address"
          value={draft}
          onChangeText={(text) => {
            setDraft(text);
            setFeedback(null);
          }}
          onSubmitEditing={save}
          placeholder="http://192.168.1.42:8765"
          placeholderTextColor={colors.textFaint}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          returnKeyType="done"
          selectionColor={colors.accent}
          style={[styles.input, feedback?.kind === 'error' && styles.inputError]}
        />
        <Button label="Save address" icon="save" disabled={!dirty} onPress={save} />
        {feedback ? (
          <Text
            accessibilityLiveRegion="polite"
            style={[styles.feedback, { color: feedback.kind === 'error' ? colors.danger : colors.success }]}
          >
            {feedback.kind === 'error' ? `ERROR · ${feedback.message}` : feedback.message}
          </Text>
        ) : null}
        <Text style={styles.hint}>Stored locally. The demo transport never connects to this address.</Text>
      </View>

      <SectionHeader title="Sessions" detail={`${onMachine.length}`} />
      <View style={styles.list}>
        {onMachine.length === 0 ? (
          <Text style={styles.empty}>NO SESSIONS</Text>
        ) : (
          onMachine.map((session) => <SessionRow key={session.id} session={session} />)
        )}
      </View>
    </Shell>
  );
}

const styles = StyleSheet.create({
  metrics: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  form: {
    gap: space.md,
  },
  input: {
    minHeight: layout.touch,
    paddingHorizontal: space.lg,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.hairlineStrong,
    backgroundColor: colors.canvas,
    fontFamily: fonts.mono,
    fontSize: typeScale.base,
    color: colors.text,
  },
  inputError: {
    borderColor: colors.danger,
  },
  feedback: {
    fontFamily: fonts.semibold,
    fontSize: 10,
    letterSpacing: 1.8,
  },
  hint: {
    fontFamily: fonts.regular,
    fontSize: typeScale.body,
    color: colors.textMuted,
  },
  list: {
    gap: space.sm,
  },
  empty: {
    fontFamily: fonts.mono,
    fontSize: 11,
    letterSpacing: 1.8,
    color: colors.textFaint,
  },
});
