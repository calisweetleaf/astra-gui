import { useCallback } from 'react';
import { Composer } from '../../../../components/agent/Composer';
import { PlannedNotice, UnknownRoute } from '../../../../components/agent/Notices';
import { StreamView } from '../../../../components/agent/StreamView';
import { machineFor, sessionStatusMeta } from '../../../../components/agent/format';
import { approvalIdOf, useApprovalDecisions } from '../../../../components/agent/useApprovalDecisions';
import { useProviderParam, useSessionParam } from '../../../../components/agent/useRouteParams';
import { useSessionStream } from '../../../../components/agent/useSessionStream';
import { Chip } from '../../../../components/ui/Chip';
import { Shell } from '../../../../components/ui/Shell';
import type { ProviderDef } from '../../../../providers/registry';
import { useAstra } from '../../../../state/agent-store';
import type { StreamEvent } from '../../../../transport';

export default function SessionScreen() {
  const provider = useProviderParam();
  const sid = useSessionParam();

  if (!provider || sid.length === 0) {
    return <UnknownRoute title="Unknown session" detail="The requested agent or session id is not valid." />;
  }
  if (provider.status === 'planned') {
    return (
      <Shell title={provider.name} eyebrow="Session" back>
        <PlannedNotice provider={provider} />
      </Shell>
    );
  }
  return <ActiveSession provider={provider} sid={sid} />;
}

function ActiveSession({ provider, sid }: { provider: ProviderDef; sid: string }) {
  const { machines, sessions } = useAstra();
  const session = sessions.find((candidate) => candidate.id === sid && candidate.provider === provider.id);
  const machine = (session && machineFor(machines, session.deviceId)) ?? machines[0];

  const { events, busy, submit } = useSessionStream(machine, provider.id, sid);
  const { states, decide } = useApprovalDecisions();

  const onDecide = useCallback(
    (event: StreamEvent, decision: 'allow' | 'deny') => {
      void decide({ machine, provider: provider.id, sessionId: sid, approvalId: approvalIdOf(event) }, decision);
    },
    [decide, machine, provider.id, sid],
  );

  const meta = session ? sessionStatusMeta(session.status) : undefined;

  return (
    <Shell
      title={session?.title ?? sid}
      eyebrow={`${provider.name} · ${machine.name}`}
      back
      scroll={false}
      headerRight={meta ? <Chip label={meta.label} tone={meta.tone} dot pulse={meta.pulse} /> : undefined}
      footer={<Composer commands={provider.commands} onSubmit={(input) => void submit(input)} busy={busy} />}
    >
      <StreamView
        events={events}
        approvalStates={states}
        onDecide={onDecide}
        busy={busy}
        emptyLabel="NO EVENTS · SEND A COMMAND TO REPLAY THE DEMO STREAM"
      />
    </Shell>
  );
}
