import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { DiffCard, summarizeDiff } from '../../../components/agent/DiffCard';
import { PlannedNotice, UnknownRoute } from '../../../components/agent/Notices';
import { useProviderParam } from '../../../components/agent/useRouteParams';
import { useTransportReplay, type ReplayRequest } from '../../../components/agent/useTransportReplay';
import { Chip } from '../../../components/ui/Chip';
import { SectionHeader } from '../../../components/ui/SectionHeader';
import { Shell } from '../../../components/ui/Shell';
import type { ProviderDef } from '../../../providers/registry';
import { useAstra } from '../../../state/agent-store';
import { colors, fonts, space, type as typeScale } from '../../../theme/tokens';
import type { StreamEventKind } from '../../../transport';

const DIFF_KINDS: StreamEventKind[] = ['diff'];

export default function ChangesScreen() {
  const provider = useProviderParam();
  if (!provider) {
    return <UnknownRoute title="Unknown agent" detail="The requested agent is not in the provider registry." />;
  }
  if (provider.status === 'planned') {
    return (
      <Shell title="Working tree" eyebrow={`${provider.name} · planned`} back>
        <PlannedNotice provider={provider} />
      </Shell>
    );
  }
  return <ActiveChanges provider={provider} />;
}

function ActiveChanges({ provider }: { provider: ProviderDef }) {
  const { machines } = useAstra();
  const machine = machines[0];

  const requests = useMemo<ReplayRequest[]>(
    () => [
      {
        key: `${provider.id}-changes`,
        machine,
        provider: provider.id,
        sessionId: `${provider.id}-changes`,
        input: 'git diff',
      },
    ],
    [machine, provider.id],
  );
  const { results, loading, failure } = useTransportReplay(requests, DIFF_KINDS);
  const diffs = results.flatMap((result) => result.events.map(summarizeDiff));

  return (
    <Shell title="Working tree" eyebrow={`${provider.name} · ${machine.name}`} back>
      <Chip label="Demo fixture" tone="neutral" dot />
      <SectionHeader title="Changed files" detail={`${diffs.length}`} />
      <View style={styles.list}>
        {loading ? <Text style={styles.empty}>LOADING</Text> : null}
        {failure ? (
          <View style={styles.failure}>
            <Text style={styles.failureLabel}>ERROR</Text>
            <Text style={styles.failureText}>{failure}</Text>
          </View>
        ) : null}
        {!loading && !failure && diffs.length === 0 ? <Text style={styles.empty}>NO CHANGES</Text> : null}
        {diffs.map((diff, index) => (
          <DiffCard key={`${diff.path}:${index}`} diff={diff} initiallyOpen />
        ))}
      </View>
    </Shell>
  );
}

const styles = StyleSheet.create({
  list: {
    gap: space.md,
  },
  empty: {
    fontFamily: fonts.mono,
    fontSize: 11,
    letterSpacing: 1.8,
    color: colors.textFaint,
  },
  failure: {
    gap: space.xs,
  },
  failureLabel: {
    fontFamily: fonts.semibold,
    fontSize: 10,
    letterSpacing: 1.8,
    color: colors.danger,
  },
  failureText: {
    fontFamily: fonts.mono,
    fontSize: typeScale.body,
    color: colors.textSecondary,
  },
});
