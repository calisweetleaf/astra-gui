import { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { ApprovalCard } from '../components/agent/ApprovalCard';
import { machineFor } from '../components/agent/format';
import { approvalIdOf, useApprovalDecisions } from '../components/agent/useApprovalDecisions';
import { useTransportReplay, type ReplayRequest } from '../components/agent/useTransportReplay';
import { Chip } from '../components/ui/Chip';
import { SectionHeader } from '../components/ui/SectionHeader';
import { Shell } from '../components/ui/Shell';
import { providers } from '../providers/registry';
import { useAstra } from '../state/agent-store';
import { colors, fonts, space, type as typeScale } from '../theme/tokens';
import type { StreamEventKind } from '../transport';

const APPROVAL_KINDS: StreamEventKind[] = ['approval'];

export default function ApprovalsScreen() {
  const { machines, sessions } = useAstra();
  const { states, decide } = useApprovalDecisions();

  const requests = useMemo<ReplayRequest[]>(
    () =>
      sessions
        .filter((session) => session.status === 'awaiting-approval')
        .map((session) => ({
          key: session.id,
          machine: machineFor(machines, session.deviceId) ?? machines[0],
          provider: session.provider,
          sessionId: session.id,
          input: 'resume',
        })),
    [sessions, machines],
  );
  const { results, loading, failure } = useTransportReplay(requests, APPROVAL_KINDS);

  const entries = results.flatMap((result) =>
    result.events.map((event) => ({ request: result.request, event, approvalId: approvalIdOf(event) })),
  );
  const pending = entries.filter((entry) => {
    const state = states[entry.approvalId];
    return state !== 'allow' && state !== 'deny';
  }).length;

  return (
    <Shell title="Approvals" eyebrow="Inbox · all agents">
      <Chip
        label={entries.length === 0 && !loading ? 'None pending' : `${pending} pending`}
        tone={pending > 0 ? 'warning' : 'neutral'}
        dot
      />
      <SectionHeader title="Requests" detail={`${entries.length}`} />
      <View style={styles.list}>
        {loading ? <Text style={styles.empty}>LOADING</Text> : null}
        {failure ? (
          <View style={styles.failure}>
            <Text style={styles.failureLabel}>ERROR</Text>
            <Text style={styles.failureText}>{failure}</Text>
          </View>
        ) : null}
        {!loading && !failure && entries.length === 0 ? <Text style={styles.empty}>NO PENDING APPROVALS</Text> : null}
        {entries.map(({ request, event, approvalId }) => {
          const providerName = providers.find((candidate) => candidate.id === request.provider)?.name ?? request.provider;
          const session = sessions.find((candidate) => candidate.id === request.sessionId);
          return (
            <ApprovalCard
              key={approvalId}
              text={event.text}
              context={`${providerName} · ${session?.title ?? request.sessionId} · ${request.machine.name}`}
              state={states[approvalId] ?? 'pending'}
              onDecide={(decision) =>
                void decide(
                  {
                    machine: request.machine,
                    provider: request.provider,
                    sessionId: request.sessionId,
                    approvalId,
                  },
                  decision,
                )
              }
            />
          );
        })}
      </View>
      <Text style={styles.note}>DEMO · requests replayed from fixtures; decisions are not persisted.</Text>
    </Shell>
  );
}

const styles = StyleSheet.create({
  list: {
    gap: space.md,
  },
  empty: {
    fontFamily: fonts.mono,
    fontSize: 11,
    letterSpacing: 1.8,
    color: colors.textFaint,
  },
  failure: {
    gap: space.xs,
  },
  failureLabel: {
    fontFamily: fonts.semibold,
    fontSize: 10,
    letterSpacing: 1.8,
    color: colors.danger,
  },
  failureText: {
    fontFamily: fonts.mono,
    fontSize: typeScale.body,
    color: colors.textSecondary,
  },
  note: {
    marginTop: space.xl,
    fontFamily: fonts.mono,
    fontSize: 10,
    letterSpacing: 1.2,
    color: colors.textFaint,
  },
});
